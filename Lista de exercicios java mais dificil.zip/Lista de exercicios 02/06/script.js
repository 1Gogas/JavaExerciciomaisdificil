function verificarNota() {
    let nota = parseFloat(document.getElementById("notaInput").value);

    let mensagem;

    if (nota > 6) {
        mensagem = "Aprovado";
    } else if (nota >= 4 && nota <= 6) {
        mensagem = "Precisa fazer prova de recuperação";
    } else {
        mensagem = "Reprovado bobao";
    }

    let resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "<h2>Resultado</h2>" +
        "<p>" + mensagem + "</p>";
}
