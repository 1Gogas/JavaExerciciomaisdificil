function compararNumeros() {
    let num1 = parseInt(document.getElementById("num1Input").value);
    let num2 = parseInt(document.getElementById("num2Input").value);


    let mensagem;

    if (num1 > num2) {
        mensagem = "O  número 1 é maior que o número 2.";
    } else if (num1 < num2) {
        mensagem = "O  número 1  é menor que o numero 2.";
    } else {
        mensagem = "Os números são iguais.";
    }

    let resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "<h2>Resultado da Comparação</h2>" +
        "<p>" + mensagem + "</p>";
}