function verificarParOuImpar() {
    let numero = parseInt(document.getElementById("numeroInput").value);

    let mensagem;

    if (numero % 2 === 0) {
        mensagem = "O número é par.";
    } else {
        mensagem = "O número é ímpar.";
    }

    let resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "<h2>Verificação de Par ou Ímpar</h2>" +
        "<p>" + mensagem + "</p>";
}