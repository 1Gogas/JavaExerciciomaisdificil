function calcular() {
    let num1 = parseInt(document.getElementById("num1Input").value);
    let num2 = parseInt(document.getElementById("num2Input").value);

    let soma = num1 + num2;
    let subtracao = num1 - num2;
    let multiplicacao = num1 * num2;
    let divisao = num1 / num2;


    let resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "<h2>Resultados das Operações Matemáticas</h2>" +
        "<p>Soma: " + soma + "</p>" +
        "<p>Subtração: " + subtracao + "</p>" +
        "<p>Multiplicação: " + multiplicacao + "</p>" +
        "<p>Divisão: " + divisao + "</p>";
}