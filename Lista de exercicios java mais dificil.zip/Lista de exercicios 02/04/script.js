function calcular() {
    let sabor1 = document.getElementById("sabor1Input").value;
    let sabor2 = document.getElementById("sabor2Input").value;
    let sabor3 = document.getElementById("sabor3Input").value;
    let sabor4 = document.getElementById("sabor4Input").value;

    let quantidadeRefri = parseInt(document.getElementById("refrigeranteInput").value);

    let valorPizza = 12.00 * 4;
    let valorRefri = 7.00 * quantidadeRefri;
    let valorTotal = valorPizza + valorRefri;

    let resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "<h2>Pedido</h2>" +
        "<p>Sabores de Pizza:</p>" +
        "<ul>" +
        "<li>" + sabor1 + "</li>" +
        "<li>" + sabor2 + "</li>" +
        "<li>" + sabor3 + "</li>" +
        "<li>" + sabor4 + "</li>" +
        "</ul>" +
        "<p>Quantidade de Refrigerantes: " + quantidadeRefri + "</p>" +
        "<p>Valor R$ " + valorTotal.toFixed(2) + "</p>";
}