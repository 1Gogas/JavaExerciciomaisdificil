function calcular() {
    let numAlunos = parseInt(document.getElementById("numAlunosInput").value);
    let numTurmas = parseInt(document.getElementById("numTurmasInput").value);

    let pessoasPorTurma = Math.floor(numAlunos / numTurmas);
    let pessoasSemTurma = numAlunos % numTurmas;

    let resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "<h2>Resultados</h2>" +
        "<p>Quantidade de pessoas por sala: " + pessoasPorTurma + "</p>" +
        "<p>Quantidade de pessoas sem sala: " + pessoasSemTurma + "</p>";
}