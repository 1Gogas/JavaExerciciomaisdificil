function calcular() {
    let valorVendido = parseFloat(document.getElementById("valorVendidoInput").value);
    let meta = parseFloat(document.getElementById("metaInput").value);
    let metaMinima = parseFloat(document.getElementById("metaMinimaInput").value);

    let percentualMeta = (valorVendido / meta) * 100;
    let percentualMetaMinima = (valorVendido / metaMinima) * 100;


    let mensagem;
    if (valorVendido >= meta) {
        mensagem = "Parabéns! A meta foi atingida.";
    } else if (valorVendido >= metaMinima) {
        mensagem = "A meta mínima foi atingida.";
    } else {
        mensagem = "Nenhuma das metas foi atingida.";
    }

    let resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "<h2>Resultados</h2>" +
        "<p>" + mensagem + "</p>" +
        "<p>Percentual de atingimento da meta: " + percentualMeta.toFixed(2) + "%</p>" +
        "<p>Percentual de atingimento da meta mínima: " + percentualMetaMinima.toFixed(2) + "%</p>";
}